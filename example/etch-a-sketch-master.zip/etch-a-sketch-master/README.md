# etch-a-sketch

Project: HTML/CSS

http://www.theodinproject.com/web-development-101/javascript-and-jquery?ref=lnav